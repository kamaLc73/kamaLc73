/**
 * 
 */
/**
 * @author kamal
 *
 */
module tp2_xml {
	requires org.jdom2;
}