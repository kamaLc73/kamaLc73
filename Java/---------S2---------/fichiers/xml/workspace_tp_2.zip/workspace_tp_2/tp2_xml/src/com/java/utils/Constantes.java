package com.java.utils;

public interface Constantes {
	
	public static final String OUVRAGE_XML_FILEPATH = "resources/xml/ouvrages.xml";
	public static final String AUTEUR_XML_FILEPATH = "resources/xml/auteurs.xml";

		
}
