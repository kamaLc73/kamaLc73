package com.java.utils;


import java.sql.Connection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.java.beans.*;
import com.java.jdbc.*;


public class Test {
	
	public static void main(String[] args) {
		DataSource ds = new MySQLDataSource("india");
		Connection cnx = ds.getConnection();
		DataBase db = new DataBase(ds);
		
//		Client c = new Client(2, "dehbi", "kamal");
////		System.out.println(db.insertClient(c));	
//		
//		Produit p = new Produit(2, "clavier", 150, 30);
////		System.out.println(db.insertProduit(p));
//	
//		@SuppressWarnings("deprecation")
//		Commande co = new Commande(2, new Date(2024, 12, 15), 40, c, p);
//		System.out.println(db.insertCommande(co));
		
//		System.out.println(db.selectAllClients());
//		System.out.println(db.selectAllProduits());
//		System.out.println(db.selectClient(1));
//		System.out.println(db.selectProduit(1));
//		System.out.println(db.selectCommande(1));
//		System.out.println(db.selectAllCommandes());
		
//		String[] tab = {"750.99","150"};
//		System.out.println(db.updateProduit(tab, "1"));

//		String[] tab = {"bekkali","mohammed"};
//		System.out.println(db.updateClient(tab, "1"));
		
		
//		String[] tab = {"2024-05-13","5","1","1"};
//		System.out.println(db.updateCommande(tab, "1"));
		
//		System.out.println(db.deleteClient(3));
		
//		System.out.println(db.deleteProduit(3));
		
//		System.out.println(db.deleteCommande(3));
		
		
		String dateString = "2024-12-05";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date = dateFormat.parse(dateString);
            System.out.println("Date : " + date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
	}

}
