package com.java.jdbc;

public class OracleDataSource {

}
